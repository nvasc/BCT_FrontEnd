
/* @ngInject */
export default class AbcController {  
  constructor($scope) {
    this.title = 'sub controller';
  }  
};

